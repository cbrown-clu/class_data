#!/usr/bin/env python
# coding: utf-8

# In[13]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import geopandas as gpd
from shapely.geometry import Point


# ## Ventura County

# You can find the Ventura County GIS Data Service at https://venturacountydatadownloads-vcitsgis.hub.arcgis.com/ .
# 
# You can find wildlife sightings records at https://www.inaturalist.org/ .
# 
# Here are some resources I stored in my github, so that you could get started with mapmaking in Ventura County.
# 
# 

# In[2]:


mask = gpd.read_file('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/Ventura%20county%20data/Ventura_County_-_Mask.geojson').to_crs(epsg=26910)
mask.head()


# In[3]:


mask = mask[mask['county'] == 'Ventura County']


# In[4]:


mask.plot()


# In[5]:


mask.area


# In[6]:


rivers_streams = (
    gpd.read_file('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/Ventura%20county%20data/RiverStreams.geojson')
    .to_crs(epsg=26910)
    .clip(mask)
)


# In[7]:


ax = mask.plot(alpha=0.3,color='gray')
rivers_streams.plot(ax=ax)


# In[8]:


greenbelts = (
    gpd.read_file('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/Ventura%20county%20data/Greenbelts.geojson')
    .to_crs(epsg=26910)
    .clip(mask)
)


# In[9]:


ax = mask.plot(alpha=0.3,color='gray')
rivers_streams.plot(ax=ax)
greenbelts.plot(ax=ax,color='green',alpha=0.3)


# In[10]:


bobcats = pd.read_csv('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/Ventura%20county%20data/inaturalist%20bobcats%20ventura%20county.csv')


# In[11]:


bobcats.head()


# In[14]:


bobcats['geometry'] = bobcats.apply(lambda x: Point((x.longitude, x.latitude)), axis=1)
bobcats = (
    gpd.GeoDataFrame(bobcats, geometry='geometry',crs='epsg:4326')
    .to_crs(epsg=26910)
    .clip(mask)
)
bobcats.head()


# In[15]:


ax = mask.plot(alpha=0.3,color='gray')
rivers_streams.plot(ax=ax)
greenbelts.plot(ax=ax,color='green',alpha=0.3)
bobcats.plot(ax=ax,marker='o',color='red',markersize=5)


# In[16]:


rivers_streams['buffer'] = rivers_streams.buffer(200)
bobcats_near_water = bobcats[bobcats.within(rivers_streams['buffer'].union_all())]


# In[17]:


ax = mask.plot(alpha=0.3,color='gray')
rivers_streams.plot(ax=ax)
greenbelts.plot(ax=ax,color='green',alpha=0.3)
bobcats_near_water.plot(ax=ax,marker='o',color='red',markersize=5)


# In[18]:


bobcats_near_water.shape


# In[ ]:


bobcats.shape


# In[19]:


bobcats_in_greenbelts = bobcats[bobcats.within(greenbelts.geometry.union_all())]


# In[20]:


ax = mask.plot(alpha=0.3,color='gray')
rivers_streams.plot(ax=ax)
greenbelts.plot(ax=ax,color='green',alpha=0.3)
bobcats_in_greenbelts.plot(ax=ax,marker='o',color='red',markersize=5)


# In[ ]:




