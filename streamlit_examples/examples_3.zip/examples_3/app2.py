#!/usr/bin/env python
# coding: utf-8

import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import geopandas as gpd
from shapely.geometry import Point

@st.cache_data
def load_data():
    mask = gpd.read_file('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/Ventura%20county%20data/Ventura_County_-_Mask.geojson').to_crs(epsg=26910)
    return mask
mask = load_data()

st.title("Ventura County and Surrounding Regions")
highlight_options = st.sidebar.multiselect("Select areas to highlight", options=mask['county'].unique(), default="Ventura County")
fig_height = st.sidebar.slider("Figure height", min_value=1, max_value=100, value=5, step=1) / 5

@st.cache_data
def create_plot(_mask,highlight_options,fig_height):
    fig, ax = plt.subplots(figsize=(2*fig_height, fig_height))
    mask.plot(ax=ax, color='lightgrey', edgecolor='black')
    for area in highlight_options:
        the_color = "red"
        if area == "Ventura County":
            the_color = "blue"
        mask[mask['county'] == area].plot(ax=ax, color=the_color, edgecolor='black')
    ax.set_axis_off()
    return fig
fig = create_plot(mask,highlight_options,fig_height)
st.pyplot(fig,use_container_width=False)