#!/usr/bin/env python
# coding: utf-8

# In[13]:

import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import geopandas as gpd
from shapely.geometry import Point


# ## Ventura County

# You can find the Ventura County GIS Data Service at https://venturacountydatadownloads-vcitsgis.hub.arcgis.com/ .
# 
# You can find wildlife sightings records at https://www.inaturalist.org/ .
# 

# Layout

st.set_page_config(
    page_title="Bobcats in Ventura County",
    page_icon=":cat:",
    layout="wide",
)
st.title("Bobcat Sightings in Ventura County")

selection = st.sidebar.multiselect(
    "Select map elements for display:",
    ["Rivers and Streams", "Greenbelts", "Bobcats"],
    default=["Bobcats"],
)

bobcat_marker_size = st.sidebar.slider(
    "Bobcat marker size",
    min_value=1,
    max_value=20,
    value=5,
    step=1,
)

fig_height = st.sidebar.slider(
    "Figure height",
    min_value=1,
    max_value=25,
    value=10,
    step=1,
) / 5

spacer,col1 = st.columns([1, 6])

# In[2]:

@st.cache_data
def load_data():
    mask = gpd.read_file('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/Ventura%20county%20data/Ventura_County_-_Mask.geojson').to_crs(epsg=26910)
    mask = mask[mask['county'] == 'Ventura County']
    rivers_streams = (
        gpd.read_file('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/Ventura%20county%20data/RiverStreams.geojson')
        .to_crs(epsg=26910)
        .clip(mask)
    )
    greenbelts = (
        gpd.read_file('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/Ventura%20county%20data/Greenbelts.geojson')
        .to_crs(epsg=26910)
        .clip(mask)
    )
    bobcats = pd.read_csv('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/Ventura%20county%20data/inaturalist%20bobcats%20ventura%20county.csv')
    bobcats['geometry'] = bobcats.apply(lambda x: Point((x.longitude, x.latitude)), axis=1)
    bobcats = (
        gpd.GeoDataFrame(bobcats, geometry='geometry',crs='epsg:4326')
        .to_crs(epsg=26910)
        .clip(mask)
    )
    return mask, rivers_streams, greenbelts, bobcats
mask, rivers_streams, greenbelts, bobcats = load_data()

@st.cache_data
def create_map(selection,bobcat_marker_size,fig_height):
    fig, ax = plt.subplots(figsize=(2*fig_height, fig_height))
    mask.plot(ax=ax, alpha=0.3, color='gray')
    if "Rivers and Streams" in selection:
        rivers_streams.plot(ax=ax)
    if "Greenbelts" in selection:
        greenbelts.plot(ax=ax, color='green', alpha=0.3)
    if "Bobcats" in selection:
        bobcats.plot(ax=ax, marker='o', color='red', markersize=bobcat_marker_size)
    return fig
fig = create_map(selection,bobcat_marker_size,fig_height)
col1.pyplot(fig, use_container_width=False)
col1.markdown(
    """
    ### Data Sources
    - [Ventura County GIS Data Service](https://venturacountydatadownloads-vcitsgis.hub.arcgis.com/)
    - [iNaturalist Bobcat Sightings](https://www.inaturalist.org/)
    """
)

