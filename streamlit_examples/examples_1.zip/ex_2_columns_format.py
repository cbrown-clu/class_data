# streamlit run columns_format_example.py
import streamlit as st

# Set this option to wide if you plan to display on larger screens
st.set_page_config(page_title="Example 2")

# instantiate the columns
col1,col2,col3 = st.columns([1,3,1])

# now each column is an object that has more or less the same methods as the main streamlit object
# Laying out column 1
col1.markdown(''''
## Title of app here
And then write a brief description of the app here.
''')

# Laying out column 2
import pandas as pd
@st.cache_data
def get_data(url,columns_to_view=None):
    data = pd.read_csv(url)
    if columns_to_view is None:
        the_columns = data.columns
    else:
        the_columns = columns_to_view
    data = data[the_columns]
    return data
data = get_data('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/iris.csv',columns_to_view=['species','sepal length'])
col2.markdown('''
## Check out this data, it's great!
''')
col2.dataframe(data)
col2.markdown("You can also create a data editor.  You can use this to play *what if* games with data.  I don't know if this is a great idea, but you can do it.")
col2.data_editor(data, num_rows="dynamic", hide_index=True, use_container_width=True)

# Laying out column 3
col3.markdown(''''
## Details
Write some more detailed info about the app here.
''')