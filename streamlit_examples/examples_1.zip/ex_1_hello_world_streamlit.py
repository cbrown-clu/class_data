# streamlit run hello_world_streamlit.py
# This is a simple Streamlit app that displays "Hello, World!" with some formatting.
import streamlit as st
st.write('Hello, *World!* :sunglasses:')
st.markdown(''''
# This is a header in `markdown`.
## This is a subheader in `markdown`
### This is a sub-subheader in `markdown`
You can format text in markdown using *italics*, **bold**, and `code`.   This is exactly the same as your capabilities in Jupyter notebooks in Colab.
''')