# streamlit run ex_3_dropdown_menu.py
import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

st.set_page_config(page_title="Example 3")

# This is a simple Streamlit app that displays a dropdown menu and a plot based on the selected option.
@st.cache_data
def get_data(url,columns_to_view=None):
    data = pd.read_csv(url)
    if columns_to_view is None:
        the_columns = data.columns
    else:
        the_columns = columns_to_view
    data = data[the_columns]
    return data
data = get_data('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/iris.csv')


st.title("Example 3")

col1,col2 = st.columns([1,2])

col1.markdown('''
    ## Iris Measurements by Species
    Select a measurement to summarize it by species with a boxplot.
''')

dropdown_choice = col1.selectbox("Measurement", ['sepal length', 'sepal width', 'petal length', 'petal width'])

col1.markdown(f"You selected {dropdown_choice}")

@st.cache_data
def get_boxplot(dropdown_choice):
    fig,ax = plt.subplots()
    sns.boxplot(x='species', y=dropdown_choice, data=data, palette="bright",ax=ax)
    return fig
the_plot = get_boxplot(dropdown_choice)

@st.cache_data
def get_densityplot(dropdown_choice):
    fig,ax = plt.subplots()
    sns.kdeplot(x=dropdown_choice, hue='species',data=data, palette="bright",ax=ax)
    return fig
the_density = get_densityplot(dropdown_choice)

col2.write("## Boxplot")
col2.pyplot(the_plot, use_container_width=True)
col2.pyplot(the_density, use_container_width=True)