#!/usr/bin/env python
# coding: utf-8

# import the packages
import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsRegressor

st.set_page_config(page_title="Example 4",layout="wide")
st.title("Example 4")

col1,col2,col3 = st.columns([1,2,3])

col1.markdown(''' 
    ## Predicting Abalone Shell Weight from Length and Rings
    This app predicts the shell weight of an abalone based on its length and number of rings.
''')

Length = col2.slider("Length", min_value=0.0, max_value=1.0, value=0.5, step=0.01, format="%.2f")
Rings = col2.slider("Rings", min_value=0, max_value=30, value=15, step=1)

# acquire the data
@st.cache_data
def get_data(url,columns_to_view=None):
    data = pd.read_csv(url)
    if columns_to_view is None:
        the_columns = data.columns
    else:
        the_columns = columns_to_view
    data = data[the_columns]
    return data
data = get_data('https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/abalone.csv',
                columns_to_view=['Length','Rings','Shell weight'])

# load the model
import joblib
def load_model(model_path,scaler_path):
    # Load the model from the file
    knn_model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)
    # Return the model and scaler
    return knn_model,scaler
knn_model,scaler = load_model('models/knn_model.pkl','models/scaler.pkl')


# make predictions with the model
@st.cache_data
def predict(Length,Rings):
    # Create a DataFrame with the input data
    input_data = pd.DataFrame({'Length': [Length], 'Rings': [Rings]})
    
    # Standardize the input data using the same scaler used for training
    input_data_scaled = scaler.transform(input_data)
    input_data_scaled = pd.DataFrame(input_data_scaled, columns=input_data.columns)
    
    # Make predictions using the loaded model
    prediction = knn_model.predict(input_data_scaled)
    
    return prediction[0]

prediction = predict(Length,Rings)



# plot the shell weight versus the length
# and then plot a predicted value
@st.cache_data
def plot_shell_weight(data, inputs):
    print(inputs)
    weight = predict(inputs[0],inputs[1])
    print(weight)
    fig, ax = plt.subplots()
    sns.scatterplot(data=data, x='Length', y='Shell weight', color='blue', label='Actual',ax=ax)
    plt.scatter(inputs[0], weight, s=80,color='red', label='Predicted')
    plt.xlabel('Length')
    plt.ylabel('Shell weight')
    plt.title('Shell Weight vs Length with Predicted Values')
    plt.legend()
    return fig
fig = plot_shell_weight(data, (Length,Rings))

col3.markdown(f"## Predicted Shell Weight: {prediction:.2f} grams")
col3.pyplot(fig, use_container_width=True)
