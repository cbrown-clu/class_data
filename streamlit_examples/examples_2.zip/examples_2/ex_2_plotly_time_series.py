#!/usr/bin/env python
# coding: utf-8

# streamlit run ex_2_plotly_time_series.py

import streamlit as st
import plotly.express as px
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import matplotlib.pyplot as plt

# Set up the page title and layout
# Check https://docs.streamlit.io/develop/api-reference/layout for layout and container options
st.set_page_config(page_title="Plotly Time Series", layout="wide")
st.title("Plotly Time Series")

col1,col2,col3 = st.columns([3,1,6])  # col2 is a spacer

# import the data
@st.cache_data
def load_data():
    data = pd.read_csv('datasets/data_year.csv',header=[0,1])
    return data
data = load_data()
variable_names = list(data.columns.levels[0][0:(-1)])  # Exclude the first column (year)

# Column 1
# select the variable to plot
# and the scale for the standard deviation boundary
col1.markdown(''' 
    ## Choose a variable
    Select the variable to plot.
''')
variable_to_plot = col1.selectbox(
    'Variable',
    options = variable_names
)
col1.markdown(''' 
    ## Choose the standard deviation scaling
''')
std_scale = col1.slider(
    'Standard deviation scaling',
    min_value=0.0,
    max_value=3.0,
    value=1.0,
    step=0.1
)

# Column 2
# Just here for spacing

# Column 3
# Creating the plot
def create_plot(trace_name):
    fig = go.Figure([
        go.Scatter(
            name=trace_name,
            x=data['Year']['Unnamed: 0_level_1'].values,
            y=data[trace_name]['mean'].values,
            mode='lines+markers',
            line=dict(color='rgb(31, 119, 180)'),
            showlegend=False
        ),
        go.Scatter(
            name='Upper Bound',
            x=data['Year']['Unnamed: 0_level_1'].values,
            y=data[trace_name]['mean'].values+std_scale * data[trace_name]['std'].values,
            mode='lines',
            marker=dict(color="#444"),
            line=dict(width=0),
            showlegend=False
        ),
        go.Scatter(
            name='Lower Bound',
            x=data['Year']['Unnamed: 0_level_1'].values,
            y=data[trace_name]['mean'].values-std_scale * data[trace_name]['std'].values,
            marker=dict(color="#444"),
            line=dict(width=0),
            mode='lines',
            fillcolor='rgba(68, 68, 68, 0.3)',
            fill='tonexty',
            showlegend=False
        )
    ])
    fig.update_layout(
        yaxis=dict(title=dict(text=trace_name+' over the decade')),
        hovermode="x unified",
    )
    return fig
fig = create_plot(variable_to_plot)
col3.plotly_chart(fig, use_container_width=True)
