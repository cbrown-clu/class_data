#!/usr/bin/env python
# coding: utf-8

# streamlit run ex_1_plotly_basics.py

import streamlit as st
import plotly.express as px
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import matplotlib.pyplot as plt

# Set up the page title and layout
# Check https://docs.streamlit.io/develop/api-reference/layout for layout and container options
st.set_page_config(page_title="A First Plotly App", layout="wide")
st.title("A First Plotly App")

top_expander = st.expander("Select data for hover information")

col1,col2,col3 = st.columns([2,1,4])

# Get the data
@st.cache_data
def load_data():
    df = pd.read_csv("https://github.com/cbrown-clu/class_data/raw/refs/heads/main/data/iris.csv")
    return df
data = load_data()

# Expander at top
top_expander.markdown(''' 
    ## Choose display data
    Choose the variables to display in the hover information in the plot.
''')

hover_data_info = top_expander.multiselect(
    'Hover data', 
    options=['sepal length', 'sepal width', 'petal length', 'petal width', 'species'],
    default=['petal length', 'petal width']
)

# Set up the plot
@st.cache_data
def create_plot(data, hover_data_info):
    fig = px.scatter(data, x="sepal length", y="sepal width", color="species", title="Iris Sepal Dimensions",
                 hover_data=hover_data_info)
    fig.update_layout(
        title="Iris Sepal Dimensions",
        xaxis_title="Sepal Length (cm)",
        yaxis_title="Sepal Width (cm)",
        legend_title="Species",
        font=dict(size=14),
        hoverlabel = dict(
            font_size=16,
            bgcolor="white"
        )
    )
    return fig
fig = create_plot(data, hover_data_info)

# Column 1 will hold an image
col1.image("images/flower-iris-nature-blossom-preview.jpg", caption="Iris flower", use_container_width=True)

# Column 2 is empty for spacing

# Column 3
col3.plotly_chart(fig, use_container_width=True)