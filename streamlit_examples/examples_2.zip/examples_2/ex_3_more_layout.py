#!/usr/bin/env python
# coding: utf-8

# streamlit run ex_3_more_layout.py

# In this app we'll work on more complex layouts and containers in Streamlit.
# So far we have only used columns.  Ideally we would like to use rows as well.
# But Streamlit does not have a row layout.  Instead, we can use containers to create a row layout.

import streamlit as st
import plotly.express as px
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import matplotlib.pyplot as plt

# Set up the page title and layout
# Check https://docs.streamlit.io/develop/api-reference/layout for layout and container options
st.set_page_config(page_title="Plotly Time Series", layout="wide")
#st.title("Plotly Time Series")

# Create a sidebar for the app
sidebar = st.sidebar
sidebar.markdown(''' 
    ## Exploring Classic 80's Music Hits
''')

# import the data
@st.cache_data
def load_data():
    data = pd.read_csv('datasets/data_year.csv',header=[0,1])
    return data
data = load_data()
variable_names = list(data.columns.levels[0][0:(-1)])  # Exclude the first column (year)

@st.cache_data
def load_popularity_data():
    data = pd.read_csv('datasets/popularity.csv')
    return data
popularity_data = load_popularity_data()

# Create a container for the first row
row1 = st.container()
col11,spacer1,col12 = row1.columns([4,1,12])

# Row 1 Column 1
# select the variable to plot
# and the scale for the standard deviation boundary
col11.markdown(''' 
    ## Choose a variable
    Select the variable to plot.
''')
variable_to_plot = col11.selectbox(
    'Variable',
    options = variable_names
)
col11.markdown(''' 
    ## Choose the standard deviation scaling
''')
std_scale = col11.slider(
    'Standard deviation scaling',
    min_value=0.0,
    max_value=3.0,
    value=1.0,
    step=0.1
)

for i in range(8):
    spacer1.image("images/drums.png",width=60)

# Row 1 Column 2
# Creating the plot
def create_plot(trace_name):
    fig = go.Figure([
        go.Scatter(
            name=trace_name,
            x=data['Year']['Unnamed: 0_level_1'].values,
            y=data[trace_name]['mean'].values,
            mode='lines+markers',
            line=dict(color='rgb(31, 119, 180)'),
            showlegend=False
        ),
        go.Scatter(
            name='Upper Bound',
            x=data['Year']['Unnamed: 0_level_1'].values,
            y=data[trace_name]['mean'].values+std_scale * data[trace_name]['std'].values,
            mode='lines',
            marker=dict(color="#444"),
            line=dict(width=0),
            showlegend=False
        ),
        go.Scatter(
            name='Lower Bound',
            x=data['Year']['Unnamed: 0_level_1'].values,
            y=data[trace_name]['mean'].values-std_scale * data[trace_name]['std'].values,
            marker=dict(color="#444"),
            line=dict(width=0),
            mode='lines',
            fillcolor='rgba(68, 68, 68, 0.3)',
            fill='tonexty',
            showlegend=False
        )
    ])
    fig.update_layout(
        yaxis=dict(title=dict(text=trace_name+' over the decade')),
        hovermode="x unified",
    )
    return fig
fig = create_plot(variable_to_plot)
col12.plotly_chart(fig, use_container_width=True)

# Spacing row
spacer_row = st.container()
spacer_spots = spacer_row.columns([1] * 30)
for i in range(len(spacer_spots)):
    spacer_spots[i].image("images/guitar.png",width=50)

# Row 2
row2 = st.container()
col21,spacer2,col22 = row2.columns([8,1,10])

# Row 2 Column 1
# select the year for filtration
# and the number of top songs to display
col21.markdown(''' 
    ## The Year
''')
given_year = col21.selectbox(
    'Year',
    options = popularity_data.Year.unique()
)
col21.markdown('''
    ## The Number of Artists
''')
top_number = col21.slider(
    'Number of artists to display in the table',
    min_value=1,
    max_value=20,
    value=10,
    step=1
)

#for i in range(8):
#    spacer2.image("images/drums.png",width=60)

# Row 2 Column 2
@st.cache_data
def create_popularity_table(given_year,top_number):
    return popularity_data[popularity_data.Year == given_year].drop(columns=['Year']).sort_values('Popularity', ascending=False).head(top_number)
popularity_table = create_popularity_table(given_year,top_number)
col22.dataframe(popularity_table, use_container_width=True,hide_index=True)